# Second Windows PC — validation plan

The user has confirmed a second PC with approximately 4 GB usable RAM. The development PC reportedly has approximately 4.8 GB usable RAM. The second PC is useful for clean installation and a realistic lower-memory acceptance target; it does not need to be the development/build machine.

## Establish the baseline

Record Windows edition/version and 64-bit architecture, CPU, total physical RAM, available RAM after startup, and free disk space. Clarify whether "4 GB usable" means Windows has 4 GB total addressable RAM or approximately 4 GB currently available. Windows and other apps already consume part of total RAM. Do not promise a local model will fit from the word usable alone.

No new RAM purchase is required merely to perform installer testing. Use a small synthetic reference corpus initially. Keep personal/resident records off the test corpus.

## Test sequence

1. Confirm this is a clean test account/PC without existing Private AI installation or data. Do not erase existing data to make it clean. Verify final artifact checksums.
2. Run the real installer acceptance script against the final healthcare-enabled 3.0 build, then check ordinary interactive launch, Start menu/shortcut launch, user guide, and built-in troubleshooting. The existing candidate can test packaging preliminarily, but cannot validate an engine it does not contain.
3. Test local knowledge import, indexing, search, and passage viewing with the model unloaded. Measure memory and verify that the library is persisted and only relevant passages are retrieved. An in-memory copy of the whole source library is not acceptable.
4. Test the already-used Qwen3-1.7B Q4 model with the existing 1024 MB RAM reserve. Start with a short prompt at 1024 context tokens and 128 output tokens, then test 2048 context tokens with adequate headroom. The October 1 packaged app passed at 1024 while 2048 runs were intermittent and sometimes stopped with LOW_MEMORY. This does not validate long reports at 1024. Run one inference at a time with heavy browsers and other applications closed. Retain the existing low-memory pause/unload protections. Confirm model files and all runtime dependencies work on this PC, not merely on the development PC.
5. Test retrieval plus local reasoning with a bounded evidence budget, meaningful citations, and a small synthetic resident fixture. Reduce retrieved evidence to fit context instead of silently truncating a resident record. Insufficient context must remain visible.
6. Test background indexing under memory pressure and while foreground chat runs. Indexing should pause/resume safely. Measure peak memory and restart/recovery behavior; do not lower safety reserves just to force a pass.
7. Test WhatsApp and browser companions after the basic tests. Their browser processes also use memory. Verify that adding the WhatsApp connection does not cause unchecked model loads or break read/write permissions. If concurrent work does not fit, queue/index serially or use cloud reasoning only under the existing explicit processing/privacy settings.
8. Separately test approved cloud reasoning, when configured, without changing Local Only policy or transmitting unrelated data. Cloud use is not a substitute for the local-only acceptance tests.
9. Repeat with a larger reference corpus and clinical/regulatory evaluation fixtures once the foundation works. A small model passing a simple arithmetic/source question does not establish reliable clinical reasoning.

## Release evidence

Record installer and executable hashes, actual installed-app execution, runtime/model hashes and real inference outputs, OS/CPU/memory baseline, observed peak memory, index corpus size, test settings, pauses/failures, and results of source-scope and citation checks. Return the evidence files for review. Actual second-PC testing requires the user to run the supplied bundle there or explicitly connect that machine; access is not assumed.

A stable lower-memory configuration is an acceptance result to measure. It must not be advertised as a guaranteed minimum hardware specification before testing.
