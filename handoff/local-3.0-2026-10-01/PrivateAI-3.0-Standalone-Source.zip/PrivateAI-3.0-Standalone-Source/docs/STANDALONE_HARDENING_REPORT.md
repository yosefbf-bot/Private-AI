# Private AI standalone hardening — October 1, 2026

This is a source and isolated application checkpoint for package 3.0.0, not an
accepted official release or an update to the installed 2.1.7 application.

## Scope found in the repository

The pre-change inventory is in [STANDALONE_ARCHITECTURE_AUDIT.md](STANDALONE_ARCHITECTURE_AUDIT.md).
This checkout does **not** contain an implemented Healthcare Knowledge Engine,
PCC importer, resident clinical model, surveillance rules, clinical threshold
library or PCC dashboard. It contains the healthcare requirements and plan,
general document/model analysis, reports, scheduling, projects and integrations
such as WhatsApp. A separate workspace PCC report catalogue is reference material.

Consequently, this pass hardens the existing application and adds an optional
data-source boundary. It cannot verify preservation or migration of clinical/PCC
code that is absent. The source containing that work is needed if it exists
elsewhere. The user still requires the Healthcare Knowledge Engine for official
3.0; this requirement has not been removed or silently deferred.

## Architecture and behavior changes

Provider policy now separates cloud authorization/configuration from the kind of
input being processed. Medication, regulatory and other complex text no longer
automatically bypass a configured local model solely because of their topic.
All existing processing modes remain. Missing or unapproved cloud configuration
can use local text reasoning, including a saved Cloud First preference. If cloud
escalation is unavailable, a local draft can be returned with a review notice.

A configured cloud connection failing with a network error can fall back to local
text output only before cloud output begins. Partial responses, authentication,
billing, policy errors and cancellation do not trigger this fallback. Cloud
permissions and credentials are rechecked immediately before the network call;
queued work cannot use a deleted/replaced key or newly prohibited cloud policy.
Usage records retain attempted cloud requests and avoid counting local work twice.
Existing cloud security controls and approved-project restrictions remain.

Settings and startup recognize installed automatic local model tiers as well as
custom model paths. OpenAI setup is explicitly optional. No-model startup exposes
help, files, projects and deterministic commands; AI reasoning needs a usable
model and gives a setup/error message instead of crashing the app. Known engine
and low-memory failures during inference retain their safe error codes.

## PCC off and on

`Integrations` is the single PCC configuration/capability service. It stores an
additive encrypted configuration record and reports `not_configured`, `disabled`,
`manual_import`, `sync_configured`, `sync_active` or `sync_error`. The UI and future
adapter callers use its capabilities instead of unrelated PCC booleans.

When PCC is off or its adapter is absent:

- Startup and general features continue normally.
- Import, sync and scheduled-source reads are rejected before invoking an adapter.
- Disabling/reconfiguring aborts an active read and rejects a late result even if
  an adapter ignores cancellation.
- No connection is attempted, no clinical missing-feed alert is produced and no
  resident result is invented. Source availability is unavailable, not negative.
- There is one inactive PointClickCare card under Settings → Integrations.
  No PCC navigation/dashboard is fabricated. With no adapter, the card clearly
  states that the connector and resident surveillance are not included.
- Toggling configuration does not delete existing records.

There is no production PCC adapter to turn on in this build. With a registered
adapter, manual/sync controls reflect the adapter's actual supported operations.
Manual mode permits imports and blocks scheduled synchronization. Sync errors
remain operational state, not clinical abnormalities. Re-enabling restores
capability access; encrypted data survives a reopen in synthetic migration tests.
These tests do not demonstrate real PCC import compatibility.

## Clinical intelligence independent of PCC

The existing general model reasoning, manual text, uploaded text/CSV, XLSX, DOCX
and text-PDF analysis, project instructions, report generation/export and ordinary
scheduling remain independent of PCC. They can process healthcare material a user
supplies, within the configured model's context/capabilities. Scanned PDF OCR and
the richer clinical analytics/knowledge framework remain unimplemented.

Shared model instructions distinguish facts from interpretation, unknown,
unavailable, stale and incomplete information from explicitly confirmed absence.
They prohibit claiming access to unsupplied feeds or verified current guidance
without live evidence. This is an instruction safeguard, not a deterministic
clinical rule system or a guarantee that a model follows it in every case.

No new validated antipsychotic, falls, infection, weight, wound, laboratory,
readmission or other resident surveillance rules are claimed. The absent domain
engine still needs normalized records with explicit evidence states, provenance
and observation dates before those clinical acceptance tests can be meaningful.

## WhatsApp communication and alerts

The existing read-all toggle, independent selected-conversation writes, verified
unattended-reply exception and disable-all-writing override remain intact.
Approved incoming AI questions use the same local/optional-cloud routing as
desktop chat. A synthetic full bridge/Core/router test covers a keyless clinical
text reply with PCC disabled; it is not live delivery evidence.

New optional `notifyJobs` alerts report completed/failed report jobs executed on
this PC to the configured default conversation. This includes local scheduled
report execution. The option is off by default. Alerts disclose only the shortened
task ID and status; no title, resident information, content, findings or file path.
Completion/failure switches, selected write permission, verified background
permission, lock policy, paused background work and disable-all-writing apply.
Read-all on/off is independent. Duplicate events do not resend, old jobs are not
replayed, and uncertain delivery is not retried.

Remote Worker status imports do not yet trigger these report alerts. The feature
does not provide clinical surveillance notifications, attachments or guaranteed
delivery. Actual account pairing, incoming events and outgoing messages remain
unverified. No real WhatsApp messages were sent during this work. See
[WHATSAPP_PERMISSIONS.md](WHATSAPP_PERMISSIONS.md) for setup and limits.

## Remaining Internet and service dependencies

Core startup, encrypted storage, non-AI tools and installed local text models do
not require an OpenAI account/key, PCC or Internet service. Models and the Windows
inference runtime must already be present; downloads need Internet or files can
be supplied locally. Browser assets used by the UI are bundled.

WhatsApp requires Internet and a connected account even with local AI. Live web
access and optional OpenAI requests require their respective services. The bundled
local engine supports text; image interpretation and integrated web search still
require the optional cloud path, subject to existing privacy policy. The optional
browser/Outlook/Worker workflows retain their own application, connectivity and
approved-folder requirements. Local report export needs an approved writable
folder, not a mandatory ShareSync account. Alternate cloud providers are not
implemented; the OpenAI-specific transport remains isolated in its client module.

## Files changed in this pass, grouped by function

| Function | Files |
| --- | --- |
| Provider policy, local reasoning and diagnostics | `source/provider-policy.cjs`, `source/hybrid-router.cjs`, `source/core.cjs`, `source/local-brain.cjs`, `source/security.cjs` |
| Optional PCC capability/configuration and UI | `source/integrations.cjs`, `source/main.cjs`, `source/ui/integrations.mjs`, `source/ui/app.mjs` |
| WhatsApp report alerts | `source/messaging.cjs`, `source/ui/messaging.mjs`, Core/main job-finished event wiring |
| Setup/output presentation | `source/ui/hybrid.mjs`, `source/ui/response-layout.mjs`, `source/ui/index.html` |
| Regression and UI coverage | `tests/standalone.test.cjs`, `tests/integrations.test.cjs`, `tests/main-startup.test.cjs`, `tests/messaging-hybrid.test.cjs`, `tests/local-startup.test.cjs`, `tests/local-tiers.test.cjs`, `tests/resources.test.cjs`, `tests/ui-check.cjs` |
| Windows evidence/build tooling | `source/windows-validation.cjs`, `build/run-windows-application.cjs`, `build/create-windows-candidate.cjs`, generated `source/build-info.json` |
| Help and handoff | `source/app-guide.json`, generated `docs/USER_GUIDE.md`, `docs/USER_GUIDE.html`, `docs/ASSISTANT_GUIDE.md`, `README.md`, architecture audit, this report, tracker/release status, WhatsApp and second-PC guides, `docs/validation/` evidence, `build/export-work-handoff.py` |

The cumulative handoff manifest also lists earlier changes against the original
2.1.7 source. Build-generated browser files and results may appear there. It is
the exact machine-readable file list; this table explains the current pass.

## Automated tests and final audit

- **262/262 regression tests pass**, no failures or skips:
  `Validation/standalone-tests.tap`. Includes offline/keyless/no-PCC startup;
  no-model tools; local clinical text in all four modes; provider revocation,
  network/partial/auth/cancellation behavior; usage accounting; generic CSV-to-
  report processing; WhatsApp reply and alert policies; memory error diagnostics.
- **28 UI checks pass**: `build/ui-results.json`,
  `Validation/standalone-ui.log`. PCC off, synthetic adapter/manual mode, general
  navigation and installed automatic-model startup were reviewed. Screenshots:
  `Validation/standalone-pcc-off.png` and
  `Validation/standalone-manual-adapter-synthetic.png`.
- Messaging UI and synthetic browser DOM send check pass:
  `Validation/standalone-messaging-ui.log`. No live account is implied.
- **104 JavaScript files passed syntax checks**; the final validation harness was
  checked again after its last edit. No lint or TypeScript task is configured.
- Repository/startup/provider/PCC searches were reviewed, including schedules,
  job completion, alert generation, security boundaries and encrypted persistence.
  Audit search outputs are in `Validation/standalone-pcc-audit.txt` and
  `Validation/standalone-provider-audit.txt`. No unconditional PCC runtime remains;
  there was no production PCC runtime in this checkout to begin with.

Integration tests use explicitly synthetic read adapters and dummy encrypted
imports/rules/alerts. They verify gating and record retention, not medical
correctness, existing PCC imports or a historical clinical schema migration.

## Actual Windows execution

**Actual packaged Windows application and local-model inference passed** on
October 1 using isolated test data. Evidence:
`Validation/standalone-final-1024-20261001/application-evidence.json`; a copy is
included at [validation/standalone-application-evidence.json](validation/standalone-application-evidence.json).
Process exit code was 0. The run exercised the real renderer/preload IPC, DPAPI
vault, SQLite, deterministic calculation, Messaging controls, optional PCC Settings
and disabled capability state. No API key or PCC connection was configured.

The actual Qwen3-1.7B Q4 model answered the synthetic missing-medication-data
question with `unknown`, using **1024 context tokens and 128 maximum output
tokens**. The response used the local provider and made no OpenAI request. The
memory reserve was not reduced. Available RAM rounded to 2.9 GiB before inference
and 1.0 GiB afterward: this is a narrow success with little headroom, not a hardware
minimum guarantee or a long-report/clinical-quality evaluation. Models were stopped
after each test; no real user profile or account was used.

Final tested hashes:

| Artifact | SHA-256 |
| --- | --- |
| `PrivateAI.exe` | `ac22821e3662644846a996d5c91319650fc4135d834bb61d23186636eeed95f9` |
| `resources/app.asar` | `6446265cd70db2cef98b8d6e0561d8b9f3260604b1d82c85540eeb7f829c48f8` |
| Windows inference runtime | `2152d0b8dc602cd1b46dfc05638a96bc1fe1c6165e63607e58f94f7e44840112` |
| Model | `72c5c3cb38fa32d5256e2fe30d03e7a64c6c79e668ad84057e3bd66e250b24fb` |

Two earlier 2048-context attempts stopped with `LOW_MEMORY`; their evidence is
retained in `Validation/standalone-final-20261001` and
`Validation/standalone-final-20261001-retry`, with copies under docs/validation.
They refer to the immediately preceding package, before the test harness gained
configurable context/output limits; the application memory policy was unchanged.
An earlier diagnostic package also passed at 2048, so the larger context was
intermittent under the available memory. These failures were not relabeled as
successful tests. No unrelated user applications were closed.

Offline startup is covered by network-denying automated tests and local-only
packaged execution. Physically disconnecting Windows networking was not tested.
**The installer was not executed.** The older installer/portable remains unchanged
and does not contain this hardening pass. Actual installer acceptance on the second
PC, live WhatsApp, real PCC imports and the missing Healthcare Knowledge Engine
remain outstanding. The release gate has not been weakened.

## Persistence, migration and risks

SQLite schema version 3 is unchanged. The integration record is additive; unknown
existing configuration fields are retained. Existing projects, chats, settings,
imports, rules, alerts, automations and credential storage are not deleted or
reset. Existing installations without `notifyJobs` default to no report-job alerts.
Existing WhatsApp response/privacy preferences are retained.

Synthetic encrypted-store reopen tests and actual fresh DPAPI/SQLite startup pass.
A real old PCC installation cannot be tested because its source/schema is absent.
The real user database and installed application were not migrated or modified.

Local replies may now be returned where the old topic heuristic demanded cloud.
They remain reviewable drafts, with limitations visible. Small-model clinical
quality has not been established. Limited available RAM can stop loading or
inference; the safety reserve remains in force. An earlier generic inference
failure was not conclusively diagnosed; later runs explicitly reported memory
pressure. The unofficial WhatsApp account connector remains dependent on service
compatibility and needs live acceptance. No installer, signing or automatic-update
acceptance is implied by the source/test checkpoint.

## Future PCC adapter connection point

Trusted application code can register `core.integrations.register('pcc', adapter)`.
The optional adapter methods are `readImport(input, {signal})` and
`readSync(input, {signal})`. Callers must use
`core.integrations.read('pcc', 'import' | 'sync' | 'scheduled', input, {signal})`
so one capability service enforces availability, lock state and cancellation.
Adapters read/parse/normalize only: they must not directly publish alerts or
persist results. After a successful guarded read, a future ingestion service
should validate and persist normalized data and invoke the same domain engine
used for manual/generic imports. It must preserve provenance, evidence states and
freshness. That normalized schema and domain engine are not supplied by this
capability service.

PCC API, corporate relay, approved file drop, SFTP or ShareSync mechanisms can
implement this boundary once their access/security contracts and the clinical
domain implementation are supplied. No credentials, module paths or arbitrary
adapter code can be registered by the renderer.

## Using and continuing this checkpoint

Use the updated [user guide](USER_GUIDE.html) for the implemented features. Source
changes require a rebuilt application; opening the installed 2.1.7 app does not
activate them. The isolated unpacked candidate is for testing and is unsigned.

For ChatGPT Work, attach the new cumulative handoff and the original 2.1.7 source
ZIP, then paste `START_HERE.md` from the handoff. Its checked apply script refuses
conflicting source changes and preserves preimages. Alternatively supply the full
Standalone-Source archive, which already includes the cumulative changes. It
contains code/docs, not an installer, runtime, model, credentials or user database.
Continue from this report and the current tracker, not historical pause notices.
