# Private AI 3.0.0 — candidate status, not an accepted official release

## October 1 standalone hardening checkpoint

The current source includes the standalone/provider/PCC capability separation and
opt-in WhatsApp report-job alerts described in STANDALONE_HARDENING_REPORT.md.
The latest automated suite passes 262 tests; the UI suite passes 28 checks.
An isolated unpacked Windows application is built at
Validation/standalone-candidate/win-unpacked. Consult the hardening report for its
own application and actual-model evidence. Do not reuse earlier artifact hashes.

The existing installer/portable candidate described below predates these changes
and was not replaced. No installer containing this hardening pass has been accepted
or executed. The installed user application is unchanged. The Healthcare Knowledge
Engine and production PCC connector are absent from this checkout; the official
release remains incomplete. A newer source tree is needed to refactor existing
clinical/PCC work if that work exists elsewhere.

## Earlier packaged candidate — historical results

The user has authorized work toward 3.0 and confirmed that the Healthcare Knowledge Engine MUST be included. The current candidate contains the implemented desktop changes, browser variants, updated documentation, and local troubleshooting. The Healthcare Knowledge Engine remains specification/design only; it is NOT present in this executable. This candidate therefore does not satisfy the confirmed official release scope. Other pending capabilities are recorded in IMPLEMENTATION_TRACKER.md; do not assume every earlier requested feature is included.

Verified for this candidate:

- 229 regression tests passed, with no failures or skips.
- Actual packaged Windows application execution passed using isolated test data, including renderer IPC and real DPAPI/SQLite startup. Exact EXE/ASAR hashes are in application-evidence.json.
- The Windows executable resource version is 3.0.0.
- Actual local-model inference passed using the packaged Windows runtime and an existing Qwen3-1.7B model, with two synthetic source questions. Runtime/model hashes and actual responses are in inference-3.0-candidate.json. This is engine inference, not a clinician-reviewed healthcare evaluation or a full model-install test on a new PC.

Still required for official acceptance:

- Implement and validate the Healthcare Knowledge Engine before this release, as explicitly confirmed by the user.
- Execute the real installer on the user's second Windows test PC once the final build is ready. The installer has been built, not executed. The second PC reportedly has approximately 4 GB usable RAM. Do not overwrite an existing Private AI installation just to run validation.
- Complete live integration acceptance or explicitly document agreed limitations. Live WhatsApp and Firefox integration remain unverified.
- Check the current actual-model-inference report when present; earlier engine results do not substitute for current evidence.

The installer is unsigned. No signing certificate/service or release hosting has been provided. There is no completed automatic-update service.

Use build/Test-CleanWindowsInstall.ps1 on a clean Windows test environment with the expected installer, executable, and ASAR hashes. It runs the installer, validates the installed payload and application, and creates installer-evidence.json. It refuses existing Private AI installations/data. Leave the test environment available for subsequent checks. The release-evidence gate rejects missing or mismatched installer execution evidence.

Do not describe a candidate ZIP, generated guide, or passing synthetic test suite as proof that the official release is finished.
