# Standalone architecture audit and implementation plan

Inspected 2026-09-30, before changing application code. Target: the existing
`PrivateAI-2.1.7-Source/PrivateAI-2.1.7-Source` checkout, package 3.0.0.

## Source inventory and scope discrepancy

Repository searches covered source, tests, browser extension, desktop helper,
build scripts and documentation (excluding dependencies and generated releases).
There is **no implemented PointClickCare integration** in this checkout: no PCC
parser, report mapping, adapter, synchronization service, surveillance rules,
resident database, alert generator or clinical dashboard. The workspace-level
`Pasted text.txt` is a PCC report catalogue, not executable import logic. Preserve
it. The Healthcare Knowledge Engine requirements and plan explicitly describe
pending work. Do not invent an existing clinical engine or claim to have preserved
or tested absent PCC imports. A newer source location has been requested.

Existing source-independent functions are chat/model reasoning, manual text
input, file extraction (text PDF, DOCX, XLSX, text/CSV and images), project
instructions, saved report prompts, report exports, scheduler/Worker, deterministic
tools, optional browser/Outlook access and WhatsApp. They can receive healthcare
documents, but they are not a validated resident surveillance/rules engine. No
clinical threshold libraries or structured normalized resident model exist here.

## Dependencies and coupling found

- `source/main.cjs`: creates the encrypted SQLite/Core, local runtime manager,
  optional API client and optional services without requesting the Internet at
  startup. Renderer network traffic is denied. Model downloads, API model listing,
  API tests and browsing are explicit operations. Enabled messaging/Worker services
  retain their existing opt-in behavior. No PCC startup path exists.
- `source/core.cjs`: the OpenAI client is injected; jobs and chat share
  `HybridRouter`. Key, API model and organizational approval are required only at
  the cloud boundary. SQLite version 3, DPAPI vault, encryption, retention,
  projects, chats and access controls require no schema migration for this work.
- `source/hybrid-router.cjs`: a keyword heuristic routes medication, regulatory,
  treatment and other complex **text** requests straight to cloud, bypassing a
  configured local model. This incorrectly couples subject matter to OpenAI.
  Low-confidence local output also attempts cloud escalation even when no key or
  model is configured. Cloud First with missing setup does not try local.
- Local inference uses the bundled llama.cpp executable and authenticated
  loopback HTTP. It supports text, not image interpretation or live web search.
  Models can be selected from disk; downloads are optional and never automatic.
- `source/ui/app.mjs`: Settings presents connecting OpenAI as step 1. Startup
  checks only the custom-model path, overlooking installed automatic tiers.
- `source/worker.cjs`, `source/schedules.cjs`, `source/messaging.cjs`: ordinary jobs
  eventually use the same router. There are no PCC jobs or absent-feed alerts to
  refactor. Report jobs need an available approved work folder, not ShareSync as a
  service. WhatsApp and remote web operations inherently need a network.
- `source/sectioned-report.cjs`: bounded local sections already exist; use the
  shared router. No clinical-specific processing path exists.

## Implementation plan

1. Add a small provider capability/policy module shared by router and summary/UI.
   Separate authorization, configuration and operation-specific capabilities.
   Preserve existing modes/preferences and approved-cloud restrictions.
2. Allow local text reasoning regardless of clinical/regulatory topic. Missing
   cloud configuration must not force an API setup error when local AI can work.
   Keep web/image limitations explicit. Retain local drafts if cloud escalation
   is unavailable; permit network-failure fallback only before any cloud output.
   Never retry partial output or override cancellation/privacy restrictions.
3. Use shared source-independent analysis instructions to distinguish unsupported
   or unavailable information from confirmed negative findings. These instructions
   do not create or certify a clinical rules engine.
4. Add one PCC integration capability boundary, disabled/not configured by default,
   with encrypted configuration and adapter registration for future code. A
   missing adapter cannot be shown as connected, run or produce surveillance
   results. Expose a single inactive status in Settings. Do not create fake PCC
   parsers, feeds, dashboards or clinical results to satisfy tests.
5. Improve local-first setup copy and no-model behavior without changing saved
   settings. Existing non-AI tools, files, projects and scheduling remain available.
6. Add regressions for keyless/offline routing, cloud/privacy policy changes,
   clinical text, no-model startup, additive configuration, capability guards and
   UI. Run the complete suite and real Windows renderer/local-inference checks
   against current source where available. Label synthetic adapters and tests.
7. Update guide, tracker and implementation report. No official installer claim:
   old candidate binaries do not contain these edits and installer execution is
   still a separate release acceptance gate.

## Completion boundary

This checkout allows the standalone/provider hardening to be implemented and
verified. Refactoring and verifying existing PCC/clinical analytics requires the
source containing those features. Until supplied, the requested PCC import,
surveillance, resident-normalization and clinical migration checks remain
unavailable, rather than passed or implemented by substitute mock features.
