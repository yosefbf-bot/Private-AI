"use strict";
const { cloudAllowed } = require("./hybrid-settings.cjs");

// Configuration is not a connectivity probe or a claim that credentials work.
// Keep this separate from clinical subject matter and from integration status.
function cloudCapability(settings, keySaved, hipaa = settings.hipaa) {
  const allowed = cloudAllowed(settings);
  const configured = !!keySaved && !!settings.model;
  const reason = !allowed ? "LOCAL_ONLY"
    : !keySaved ? "KEY"
    : !settings.model ? "MODEL"
    : hipaa && !settings.approved ? "SETUP" : null;
  return { provider: "openai", allowed, configured, ready: reason === null, reason };
}

function localConfigured(settings, tiers = []) {
  if (settings.localTier === "selected") return !!settings.localModelPath;
  if (settings.localTier && settings.localTier !== "auto")
    return tiers.some(t => t.tier === settings.localTier && t.installed);
  return !!settings.localModelPath || tiers.some(t => t.installed);
}

function requiredCapability(messages, options = {}) {
  if (options.web) return "web";
  if (messages.some(m => Array.isArray(m.content) && m.content.some(p => p.type === "input_image"))) return "images";
  return "text";
}

// Shared by local and cloud reasoning over any supplied source. This is an
// instruction boundary, not a substitute for validated clinical rules.
const EVIDENCE_INSTRUCTIONS = "Separate supplied facts from interpretations. Missing information is unknown, not a confirmed negative finding. Distinguish unavailable sources, stale or incomplete data, and explicitly confirmed absence; do not infer one from another. Do not claim access to feeds or records not supplied. For clinical analysis, identify evidence gaps and review needs; do not invent diagnoses, medication status, or treatment decisions. Without live sources, do not claim current guidance was verified.";

module.exports = { cloudCapability, localConfigured, requiredCapability, EVIDENCE_INSTRUCTIONS };
