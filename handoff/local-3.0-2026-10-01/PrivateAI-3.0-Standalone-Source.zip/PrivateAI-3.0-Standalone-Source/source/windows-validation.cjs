'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const rawFs=require('original-fs');
const sha=async f=>{const hash=crypto.createHash('sha256');for await(const chunk of rawFs.createReadStream(f))hash.update(chunk);return hash.digest('hex');};
async function run({core,win,reportPath,exe,asar}){
 if(process.platform!=='win32')throw Error('Windows validation must execute on Windows');
 const evidence={version:require('../package.json').version,platform:process.platform,windowsApplicationExecuted:true,actualModelInferenceExecuted:false,passed:false,started:new Date().toISOString(),executableSHA256:await sha(exe),applicationArchiveSHA256:await sha(asar),checks:[]};
 try{
  core.saveSettings({processingMode:'local-only',allowCloud:false,workspace:path.join(path.dirname(reportPath),'reports'),approved:true});
  const deadline=Date.now()+45000;let ready=false;
  while(Date.now()<deadline){if(win.isDestroyed())throw Error('Window destroyed');try{ready=await win.webContents.executeJavaScript("!!document.querySelector('#sidebar') && !!window.privateAI && !!document.querySelector('#content')");}catch{}if(ready&&!win.webContents.isLoading())break;await new Promise(r=>setTimeout(r,200));}
  assert.equal(ready,true);evidence.checks.push('packaged renderer loaded with isolated preload');
  const summary=await win.webContents.executeJavaScript("window.privateAI.call('summary')");assert.equal(summary.ok,true);evidence.checks.push('renderer IPC summary succeeded');
  assert.equal(summary.result.keySaved,false);assert.equal(summary.result.providers.cloud.ready,false);
  assert.equal(summary.result.integrations.find(x=>x.id==='pcc').state,'not_configured');
  evidence.checks.push('keyless startup with PCC not configured and cloud disabled');
  const created=await win.webContents.executeJavaScript("window.privateAI.call('createChat',{temporary:true})");assert.equal(created.ok,true);
  const result=await win.webContents.executeJavaScript("window.privateAI.call('send',"+JSON.stringify({chatId:created.result.id,prompt:'/calc 12+7'})+")");assert.equal(result.ok,true);assert.match(result.result.chat.messages.at(-1).text,/19/);evidence.checks.push('packaged renderer IPC deterministic request completed');
  const messaging=await win.webContents.executeJavaScript("window.privateAI.call('messagingStatus')");assert.equal(messaging.ok,true);assert.equal(messaging.result.settings.readAll,true);assert.equal(messaging.result.settings.enabled,false);evidence.checks.push('packaged messaging permissions initialized');
  await win.webContents.executeJavaScript("document.querySelector('[data-view=\"messaging\"]').click()");
  let controls=false;for(let n=0;n<50;n++){controls=await win.webContents.executeJavaScript("!!document.querySelector('[name=\"wa-readAll\"]') && !!document.querySelector('[name=\"wa-disableAllWriting\"]')");if(controls)break;await new Promise(r=>setTimeout(r,100));}assert.equal(controls,true);evidence.checks.push('packaged Messaging page renders independent controls');
  const image=await win.webContents.capturePage();fs.writeFileSync(path.join(path.dirname(reportPath),'application.png'),image.toPNG());
  assert.ok(fs.existsSync(path.join(core.root,'vault.dpapi')));assert.ok(core.store.db);evidence.checks.push('real Windows DPAPI vault and SQLite startup completed');
  require('whatsapp-web.js');evidence.checks.push('packaged account connector dependency resolves');
  await win.webContents.executeJavaScript("document.querySelector('[data-view=\"settings\"]').click()");
  let settingsUI;for(let n=0;n<50;n++){settingsUI=await win.webContents.executeJavaScript("({status:document.querySelector('[data-integration=\"pcc\"] .integration-status')?.textContent,optional:document.querySelector('#content').textContent.includes('Optional OpenAI access')})");if(settingsUI.status)break;await new Promise(r=>setTimeout(r,100));}
  assert.equal(settingsUI.status,'Not connected');assert.equal(settingsUI.optional,true);
  await win.webContents.executeJavaScript("document.querySelector('[data-integration=\"pcc\"]').scrollIntoView({block:'center'})");
  const disabled=await win.webContents.executeJavaScript("window.privateAI.call('integrationSave',{id:'pcc',settings:{enabled:false}})");
  assert.equal(disabled.ok,true);assert.equal(disabled.result.state,'disabled');
  assert.equal(disabled.result.canSync,false);evidence.checks.push('real renderer Settings isolates optional PCC and disables its capabilities');
  fs.writeFileSync(path.join(path.dirname(reportPath),'standalone-settings.png'),(await win.webContents.capturePage()).toPNG());
  // Optional real inference runs only in this isolated validation mode. No
  // credentials, patient data or WhatsApp connection are used.
  if(process.env.PRIVATE_AI_VALIDATION_MODEL){
    const model=path.resolve(process.env.PRIVATE_AI_VALIDATION_MODEL);
    // Exercise the same supported settings a user can choose for a low-RAM PC.
    // Core validates the bounds; do not weaken reserves or change user defaults.
    const localContext=Number(process.env.PRIVATE_AI_VALIDATION_CONTEXT||2048);
    const localMaxOutput=Number(process.env.PRIVATE_AI_VALIDATION_OUTPUT||256);
    core.saveSettings({localModelPath:model,localTier:'selected',localContext,localMaxOutput});
    evidence.inferenceDiagnostics={before:core.router.local.status(),requests:[]};
    const originalFetch=core.router.local.fetcher;
    core.router.local.fetcher=async(url,options)=>{const response=await originalFetch(url,options);evidence.inferenceDiagnostics.requests.push({path:new URL(url).pathname,status:response.status,...(!response.ok?{error:(await response.clone().text()).slice(0,1000)}:{})});return response;};
    const originalGenerate=core.router.local.generate.bind(core.router.local);
    core.router.local.generate=async(...args)=>{try{const result=await originalGenerate(...args);evidence.inferenceDiagnostics.rawSyntheticOutput={...result,text:result.text.slice(0,2000)};return result;}finally{evidence.inferenceDiagnostics.after=core.router.local.status();}};
    const created=await win.webContents.executeJavaScript("window.privateAI.call('createChat',{temporary:true})");
    const prompt='Use only this synthetic source. Medication feed: unavailable. Medication status: unknown. What is the medication status? Reply briefly using that word; do not infer absence.';
    const response=await win.webContents.executeJavaScript("window.privateAI.call('send',"+JSON.stringify({chatId:created.result.id,prompt})+")");
    const answer=response.result?.chat.messages.at(-1);
    evidence.actualModelInferenceExecuted=answer?.processing?.provider==='local'&&!!answer.text&&!answer.error;
    evidence.inference={model:path.basename(model),modelSHA256:await sha(model),runtimeSHA256:await sha(core.router.local.runtime),localContext,localMaxOutput,response:answer?.text,error:answer?.error,provider:answer?.processing?.provider};
    assert.equal(response.ok,true);assert.equal(answer.error,undefined);assert.equal(answer.processing.provider,'local');assert.match(answer.text,/unknown/i);
    assert.equal(core.store.list('usage').filter(x=>x.provider==='openai').length,0);
    evidence.checks.push('real local inference through renderer IPC/Core/router with no key and PCC disabled; synthetic missing information stays unknown');
    core.router.local.stop('validation-complete');await core.router.local.waitStopped();
  }
  evidence.passed=true;
 }catch(e){evidence.error={message:e.message,code:e.code||null};throw e;}finally{if(process.env.PRIVATE_AI_VALIDATION_MODEL){core.router.local?.stop('validation-finished');await core.router.local?.waitStopped();}evidence.completed=new Date().toISOString();fs.writeFileSync(reportPath,JSON.stringify(evidence,null,2));}
 return evidence;
}
module.exports={run};
