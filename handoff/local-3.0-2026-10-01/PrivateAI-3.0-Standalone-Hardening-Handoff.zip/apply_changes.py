"""Apply only to the original 2.1.7 source tree or an already-applied copy."""
import argparse, hashlib, json, shutil
from pathlib import Path, PurePosixPath
p=argparse.ArgumentParser()
p.add_argument('source',type=Path)
p.add_argument('--apply',action='store_true',help='Write after all preimages are checked; otherwise check only')
a=p.parse_args()
root=a.source.resolve(strict=True); bundle=Path(__file__).resolve().parent
manifest=json.loads((bundle/'manifest.json').read_text(encoding='utf-8'))
changes=[]; conflicts=[]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
for row in manifest['changes']:
    rel=PurePosixPath(row['path'])
    if rel.is_absolute() or '..' in rel.parts or ':' in row['path'] or '\\' in row['path']: raise SystemExit('Unsafe path')
    dest=root.joinpath(*rel.parts)
    if not dest.resolve().is_relative_to(root): raise SystemExit('Path escapes source: '+str(rel))
    if any(q.is_symlink() or (hasattr(q,'is_junction') and q.is_junction()) for q in [dest,*dest.parents] if q!=root and q.is_relative_to(root)): raise SystemExit('Linked target: '+str(rel))
    current=digest(dest)
    if current==row['after']: continue
    if current!=row['before'] or (dest.exists() and not dest.is_file()): conflicts.append(str(rel)); continue
    if row['after'] is not None:
        src=bundle/'changed-files'/str(rel)
        if digest(src)!=row['after']: raise SystemExit('Corrupt handoff: '+str(rel))
    changes.append((row,dest))
if conflicts: raise SystemExit('Different source changes found; merge these manually:\n'+'\n'.join(conflicts))
print(str(len(changes))+' files ready; '+str(len(manifest['changes'])-len(changes))+' already applied.')
if not a.apply:
    print('Check only. Repeat with --apply to write after backing up your source.')
    raise SystemExit(0)
backup=root/'handoff-preimages'
if backup.exists(): raise SystemExit('Backup folder exists; choose a fresh source copy or move that backup first.')
backup.mkdir()
for row,dest in changes:
    if dest.exists():
        b=backup/row['path']; b.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(dest,b)
    if row['after'] is None: dest.unlink()
    else:
        dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(bundle/'changed-files'/row['path'],dest)
print('Applied. Run the documented tests and rebuild; this is not a validated installer.')
